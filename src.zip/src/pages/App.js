import React from 'react';
import Formulario from '../components/Formulario';
import Hooks01 from '../components/Hooks';
import Form01 from '../components/Hooks/form01';
import Form10 from '../components/Hooks/form10';
import Form11 from '../components/Hooks/form11';
import Form12 from '../components/Hooks/form12';
import Hooks02 from '../components/Hooks/hooks02';
import Hooks03 from '../components/Hooks/hooks03';
import Hooks04 from '../components/Hooks/hooks04';
import Hooks05 from '../components/Hooks/hooks05';
import Hooks06 from '../components/Hooks/hooks06';
import Hooks07 from '../components/Hooks/hooks07';
import Hooks08 from '../components/Hooks/hooks08';
import Hooks09 from '../components/Hooks/hooks09';
import Hooks10 from '../components/Hooks/hooks10';
import Hooks11 from '../components/Hooks/hooks11';
import Hooks12 from '../components/Hooks/hooks12';
import Hooks13 from '../components/Hooks/hooks13';

// https://quaddro.co/?gclid=CjwKCAjwjMiiBhA4EiwAZe6jQ0k4VcWcXcX_fzhdDskiVokRV5JfsIXsralyIqsvpiltS5lJRkHANBoCbXYQAvD_BwE
// https://www.belasis.com.br/sistema-para-salao-de-beleza/?utm_source=google&utm_medium=cpc&utm_campaign=pareto.in.gsn.geral.br.{sal%C3%A3o_beleza}&utm_source=google&utm_medium=cpc&utm_campaign=9347257125&adgroupid=126272800211&utm_content=g_c_&utm_term=b_agenda%20cabelereiro&utm_lpurl=https://www.belasis.com.br/sistema-para-salao-de-beleza/%3Futm_source%3Dgoogle%26utm_medium%3Dcpc%26utm_campaign%3Dpareto.in.gsn.geral.br.%7Bsal%C3%A3o_beleza%7D&gclid=CjwKCAjwjMiiBhA4EiwAZe6jQ8q0O-OqDJzI2JulBr1cMMOMxUlSlNvR-eHyOp-K39oAeuZBo9vY_xoCwUQQAvD_BwE
// https://www.salao99.com.br/enterprise/?campaign=gads&gad=1&gclid=CjwKCAjwjMiiBhA4EiwAZe6jQ0a3-jx8D9T8LqwQsXKsbsqLFxRV1u4g_tEmnaGJz85bTHvNuiS6ahoCbOoQAvD_BwE
// https://www.trinks.com/sao-paulo-sp?latitude=-23.5505199&longitude=-46.6333094#somenteComDesconto=false&precoInicial=&precoFinal=&dataPesquisa=03/05/2023&idCategoria=7&facilidades=

// https://blog.rocketseat.com.br/quando-utililzar-promises-e-async-await-no-useeffect-do-react/

import Lista from '../components/Lista';
import './style.scss';

function App() {
  return (
    <div className="AppStyle">
      <Form10/>
    </div>
  );
}

export default App;
